const BotaoAdicionarPizza = document.querySelectorAll(".card-area__button-add");
const modal=document.querySelector(".bkg-modal");

console.log("clicaram em mim");
for (let  i = 0;  i < BotaoAdicionarPizza.lenght; i++)
{   
    
    BotaoAdicionarPizza[i].addEventListener('click', ()=> {
        modal.classList.add("bkg-modal--ativo");
        console.log("clicaram em mim");


    })


}


